import React from 'react'

function Table() {
  return (
    <div>

        <table>

            <tr>
                <td>Name</td>
                <td>Username</td>
                <td>Email</td>
            </tr>

            <tr>
                <td>firstname</td>
                <td>username</td>
            </tr>
        </table>
      
    </div>
  )
}

export default Table
